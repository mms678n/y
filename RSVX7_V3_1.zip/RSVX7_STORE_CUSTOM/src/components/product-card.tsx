'use client'
import Link from 'next/link'
import Image from 'next/image'
import { ArrowUpRight } from 'lucide-react'
import { motion, useReducedMotion } from 'framer-motion'
import type { Product } from '@/lib/types'
import { cleanText, priceLabel } from '@/lib/format'
import { mediaUrl } from '@/lib/media'
export function ProductCard({product,index=0}:{product:Product;index?:number}) {
 const reduce=useReducedMotion()
 return <motion.article initial={reduce?false:{opacity:0,y:30}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.12}} transition={{duration:.58,delay:Math.min(index,5)*.065}} className="product-card"><Link href={`/products/${encodeURIComponent(product.slug)}`} className="product-card-link" aria-label={`View ${product.name}`}><div className="product-visual"><div className="product-mesh"/>{product.images?.[0]?.src ? <Image src={mediaUrl(product.images[0].src) || product.images[0].src} alt={product.images[0].alt || product.name} fill unoptimized sizes="(max-width: 700px) 100vw,(max-width:1100px) 50vw,33vw" className="product-img"/>:<div className="product-placeholder"><span className="placeholder-ring"/><Image src="/logo-mark.png" alt="" width={92} height={92}/><span className="placeholder-index">RSVX7 — {String(Math.abs(product.id)).padStart(2,'0')}</span></div>}{product.demo&&<span className="demo-tag">SAMPLE</span>}<span className="card-arrow"><ArrowUpRight size={20}/></span></div><div className="product-meta"><div><span className="product-category">{product.categories?.[0]?.name || 'DIGITAL PRODUCT'}</span><h3>{product.name}</h3><p>{cleanText(product.short_description)}</p></div><strong>{priceLabel(product.prices)}</strong></div></Link></motion.article>
}
