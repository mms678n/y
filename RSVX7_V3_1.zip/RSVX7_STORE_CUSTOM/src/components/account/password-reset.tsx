'use client'
import { useState, type FormEvent } from 'react'
import Link from 'next/link'
import { ArrowRight, LockKeyhole } from 'lucide-react'

export function PasswordReset({ login = '', token = '' }: { login?: string; token?: string }) {
  const [email, setEmail] = useState(login)
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [done, setDone] = useState(false)
  async function submit(event: FormEvent) {
    event.preventDefault()
    setBusy(true)
    setMessage('')
    try {
      const response = await fetch(`/api/auth/${token ? 'reset' : 'recovery'}`, {
        method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(token ? { login: email, key: token, password } : { login: email }),
      })
      const json = await response.json()
      if (!response.ok) throw new Error(json.error || 'Request failed.')
      setDone(true)
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Request failed.') }
    finally { setBusy(false) }
  }
  return <main className="page-main account-page"><div className="container"><div className="page-intro"><span className="eyebrow">RSVX7 / ACCESS</span><h1>RESET <span>ACCESS.</span></h1></div><section className="reset-panel"><LockKeyhole size={38}/><h2>{done ? 'REQUEST RECEIVED.' : token ? 'SET NEW PASSWORD.' : 'FORGOT YOUR PASSWORD?'}</h2>{done ? <p>{token ? 'Your password has been updated.' : 'If the account exists, a password reset email has been sent.'}</p> : <form className="auth-form" onSubmit={submit}><label>{token ? 'Username' : 'Email or username'}<input value={email} onChange={e => setEmail(e.target.value)} maxLength={160} required /></label>{token && <label>New password<input type="password" value={password} onChange={e => setPassword(e.target.value)} minLength={12} maxLength={128} required autoComplete="new-password"/></label>}{message && <p role="alert" className="error-box">{message}</p>}<button className="button button-light full" type="submit" disabled={busy}>{busy ? 'PLEASE WAIT...' : token ? 'SAVE PASSWORD' : 'SEND RESET LINK'}<ArrowRight size={17}/></button></form>}<Link href="/account" className="back-link">RETURN TO ACCOUNT <ArrowRight size={14}/></Link></section></div></main>
}
