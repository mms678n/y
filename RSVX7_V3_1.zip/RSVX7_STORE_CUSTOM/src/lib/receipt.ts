import { createHmac, timingSafeEqual } from 'node:crypto'

export type Receipt = {
  order_id: number
  order_number: string
  status: string
  payment_method: string
  created: number
}
const key = process.env.WC_RECEIPT_SECRET || ''
const ttl = 60 * 60 * 24

export function signReceipt(info: Receipt) {
  if (key.length < 32) throw new Error('WC_RECEIPT_SECRET must contain at least 32 characters')
  const data = Buffer.from(JSON.stringify(info)).toString('base64url')
  const mac = createHmac('sha256', key).update(data).digest('base64url')
  return `${data}.${mac}`
}
export function readReceipt(value?: string): Receipt | null {
  if (!value || key.length < 32 || value.length > 4096) return null
  const parts = value.split('.')
  if (parts.length !== 2) return null
  const [data, mac] = parts
  const expected = createHmac('sha256', key).update(data).digest()
  let received: Buffer
  try { received = Buffer.from(mac, 'base64url') } catch { return null }
  if (received.length !== expected.length || !timingSafeEqual(received, expected)) return null
  try {
    const result = JSON.parse(Buffer.from(data, 'base64url').toString()) as Receipt
    if (!Number.isSafeInteger(result.order_id) || result.order_id < 1 || !Number.isFinite(result.created) || Date.now() - result.created > ttl * 1000 || result.created > Date.now() + 60000) return null
    if (typeof result.status !== 'string' || typeof result.order_number !== 'string' || typeof result.payment_method !== 'string') return null
    return result
  } catch { return null }
}
export const receiptCookie = 'rsvx7_order_receipt'
export const receiptMaxAge = ttl
