import { createHmac } from 'node:crypto'
import { cookies } from 'next/headers'
import { wpUrl } from '@/lib/woocommerce'
import { NextResponse } from 'next/server'

export const sessionCookie = 'rsvx7_customer_session'
export const sessionSeconds = 7 * 24 * 60 * 60

const base = (process.env.WC_INTERNAL_URL || 'http://rsvx7-wp-wordpress-1').replace(/\/+$/, '')

export async function customerSession() {
  const jar = await cookies()
  const token = jar.get(sessionCookie)?.value || ''
  return /^[a-f0-9]{64}$/.test(token) ? token : ''
}

export function noStore(data: unknown, status = 200) {
  return NextResponse.json(data, {
    status,
    headers: {
      'Cache-Control': 'private, no-store',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',
    },
  })
}

export async function bridgeRequest(path: string, method: 'GET' | 'POST', payload?: unknown, token?: string, clientIp?: string) {
  if (!/^\/(auth\/(login|register|logout|recovery|reset)|account\/(me|orders|downloads|download-resolve|wallet|licenses)|checkout\/(claim|complete))$/.test(path)) {
    throw new Error('Unsupported bridge route')
  }
  const headers: Record<string, string> = { Accept: 'application/json', Host: new URL(wpUrl).host, 'X-Forwarded-Proto': 'https' }
  if (payload !== undefined) headers['Content-Type'] = 'application/json'
  if (clientIp) headers['X-Rsvx7-Client'] = createHmac('sha256', process.env.WC_RECEIPT_SECRET || 'rsvx7').update(clientIp.slice(0, 80)).digest('hex')
  if (token) { headers.Authorization = `Bearer ${token}`; headers['X-Rsvx7-Session'] = token }
  let response: Response
  try {
    response = await fetch(`${base}/wp-json/rsvx7/v1${path}`, {
      method,
      headers,
      body: payload === undefined ? undefined : JSON.stringify(payload),
      cache: 'no-store',
      redirect: 'manual',
      signal: AbortSignal.timeout(12000),
    })
  } catch {
    return { status: 503, data: { error: 'Account service is temporarily unavailable.' } }
  }
  const raw = await response.text()
  if (raw.length > 512_000) return { status: 502, data: { error: 'Unexpected account service response.' } }
  let data: Record<string, unknown>
  try {
    const candidate: unknown = JSON.parse(raw)
    if (!candidate || typeof candidate !== 'object' || Array.isArray(candidate)) throw new Error('Invalid response')
    data = candidate as Record<string, unknown>
  } catch {
    return { status: 502, data: { error: 'Account service is unavailable.' } }
  }
  return { status: response.status, data }
}

export function unauthorized() {
  return noStore({ error: 'Sign in to continue.' }, 401)
}
