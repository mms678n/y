import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { demoMode, storeBase, wpUrl } from './woocommerce'
import { customerSession } from './account-server'

export const cartCookieName = 'rsvx7_wc_cart'
const MAX_RESPONSE_BYTES = 1024 * 1024

export type WooResult = {
  status: number
  data: Record<string, unknown>
  cartToken: string | null
}

export function problem(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status, headers: { 'Cache-Control': 'no-store' } })
}

export function requireSameOrigin(req: Request) {
  const origin = req.headers.get('origin')
  const host = req.headers.get('host')
  if (!origin || !host) return false
  try {
    const u = new URL(origin)
    const canonical = process.env.UI_PUBLIC_URL
    if (canonical) return u.origin === new URL(canonical).origin && u.host === host
    return (u.protocol === 'https:' || (process.env.NODE_ENV !== 'production' && u.protocol === 'http:')) && u.host === host
  } catch { return false }
}

function isAcceptableToken(value: string | null): value is string {
  return !!value && value.length < 4096 && /^[A-Za-z0-9._~+/=-]+$/.test(value)
}

export async function requestWoo(path: string, method: 'GET' | 'POST', body?: unknown): Promise<WooResult> {
  if (demoMode) throw new WooProxyError('Demo mode cannot create carts or orders.', 409)
  if (!/^\/(cart(?:\/[-a-z]+)?|checkout)$/.test(path)) throw new WooProxyError('Invalid Store API route', 400)
  const jar = await cookies()
  const token = jar.get(cartCookieName)?.value
  if (method === 'POST' && !isAcceptableToken(token || null)) throw new WooProxyError('Cart session missing. Reload the cart and try again.', 409)

  const headers: Record<string, string> = {
    Accept: 'application/json',
    Host: new URL(wpUrl).host,
    'X-Forwarded-Proto': 'https',
  }
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  if (isAcceptableToken(token || null)) headers['Cart-Token'] = token!
  const session = await customerSession()
  if (session) headers['X-Rsvx7-Session'] = session

  let remote: Response
  try {
    remote = await fetch(`${storeBase}${path}`, {
      method, headers, cache: 'no-store', redirect: 'manual',
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(18000),
    })
  } catch (err) {
    console.error('WooCommerce network error:', err instanceof Error ? err.message : 'unknown')
    throw new WooProxyError('Could not reach WooCommerce. Check WordPress and Docker network.', 503)
  }
  const size = remote.headers.get('content-length')
  if (size && Number(size) > MAX_RESPONSE_BYTES) throw new WooProxyError('Unexpectedly large WooCommerce response.', 502)
  const text = await remote.text()
  if (text.length > MAX_RESPONSE_BYTES) throw new WooProxyError('Unexpected WooCommerce response.', 502)
  let data: unknown
  try { data = JSON.parse(text) } catch { throw new WooProxyError('WooCommerce returned a non-JSON response.', 502) }
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new WooProxyError('Invalid WooCommerce response.', 502)
  return { data: data as Record<string, unknown>, status: remote.status, cartToken: remote.headers.get('cart-token') }
}

export class WooProxyError extends Error {
  constructor(message: string, public status: number) { super(message) }
}

export function wooError(err: unknown) {
  return problem(err instanceof WooProxyError ? err.message : 'Unexpected storefront error.', err instanceof WooProxyError ? err.status : 500)
}

export async function attachWooCookie(result: WooResult, clearCart = false) {
  const response = NextResponse.json(result.data, { status: result.status, headers: { 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' } })
  if (clearCart) {
    response.cookies.set(cartCookieName, '', { path: '/', maxAge: 0 })
  } else if (isAcceptableToken(result.cartToken)) {
    response.cookies.set(cartCookieName, result.cartToken, {
      httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax',
      path: '/', maxAge: 60 * 60 * 24 * 14,
    })
  }
  return response
}

export async function proxyWoo(path: string, method: 'GET' | 'POST', body?: unknown) {
  try { return await attachWooCookie(await requestWoo(path, method, body)) }
  catch (err) { return wooError(err) }
}
