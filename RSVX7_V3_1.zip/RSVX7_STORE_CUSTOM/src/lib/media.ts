/** Proxy WordPress uploaded images through our server because preview WordPress
 *  can be protected by HTTP Basic Authentication. The API route enforces the
 *  configured WordPress host and uploads path to avoid SSRF. */
export function mediaUrl(src?: string): string | undefined {
  if (!src) return undefined
  try {
    const u = new URL(src)
    if (u.protocol === 'https:' && u.pathname.startsWith('/wp-content/uploads/')) {
      return `/api/media?src=${encodeURIComponent(src)}`
    }
  } catch { /* use src as-is */ }
  return src
}
