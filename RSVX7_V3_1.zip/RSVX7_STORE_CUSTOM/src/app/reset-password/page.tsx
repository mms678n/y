import { PasswordReset } from '@/components/account/password-reset'
export const metadata = { title: 'Reset Password | RSVX7 STORE', robots: { index: false, follow: false } }
export default async function ResetPassword({ searchParams }: { searchParams: Promise<{ key?: string; login?: string }> }) {
  const args = await searchParams
  return <PasswordReset token={(args.key || '').slice(0, 120)} login={(args.login || '').slice(0, 160)} />
}
