import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { readReceipt, receiptCookie } from '@/lib/receipt'
export const dynamic = 'force-dynamic'
export async function GET() {
  const jar = await cookies()
  const data = readReceipt(jar.get(receiptCookie)?.value)
  if (!data) return NextResponse.json({ error: 'No recent order confirmation on this device.' }, { status: 404, headers: { 'Cache-Control': 'no-store' } })
  return NextResponse.json(data, { headers: { 'Cache-Control': 'private, no-store' } })
}
