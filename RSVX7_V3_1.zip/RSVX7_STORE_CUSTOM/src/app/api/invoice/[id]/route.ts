import { NextResponse } from 'next/server'
import { customerSession } from '@/lib/account-server'
import { wpUrl } from '@/lib/woocommerce'

export const dynamic = 'force-dynamic'

const fail = (status: number) => new NextResponse('Invoice unavailable.', {
  status,
  headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' },
})

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await customerSession()
  if (!session) return fail(401)
  const { id } = await params
  if (!/^[1-9][0-9]{0,12}$/.test(id)) return fail(404)

  const base = process.env.WC_INTERNAL_URL || 'http://rsvx7-wp-wordpress-1'
  const upstreamUrl = new URL('/wp-admin/admin-post.php', base)
  upstreamUrl.searchParams.set('action', 'rsvx7_invoice')
  upstreamUrl.searchParams.set('order_id', id)

  let upstream: Response
  try {
    upstream = await fetch(upstreamUrl, {
      method: 'GET', redirect: 'manual', cache: 'no-store',
      headers: {
        Host: new URL(wpUrl).host,
        'X-Forwarded-Proto': 'https',
        'X-Rsvx7-Session': session,
        Accept: 'application/pdf',
      },
      signal: AbortSignal.timeout(25000),
    })
  } catch { return fail(503) }

  if (upstream.status === 404) return fail(404)
  if (!upstream.ok || upstream.headers.get('content-type')?.split(';')[0] !== 'application/pdf') return fail(503)
  const size = Number(upstream.headers.get('content-length') || '0')
  if (!Number.isFinite(size) || size > 8 * 1024 * 1024) return fail(503)
  let data: ArrayBuffer
  try { data = await upstream.arrayBuffer() } catch { return fail(503) }
  if (data.byteLength < 8 || data.byteLength > 8 * 1024 * 1024) return fail(503)
  const head = new TextDecoder().decode(data.slice(0, 5))
  if (head !== '%PDF-') return fail(503)
  return new NextResponse(data, {
    status: 200,
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="RSVX7-INVOICE-${id}.pdf"`,
      'Cache-Control': 'private, no-store, max-age=0',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'none'; sandbox",
      'Referrer-Policy': 'no-referrer',
    },
  })
}
