import { NextResponse } from 'next/server'
import { bridgeRequest, customerSession, noStore, sessionCookie, sessionSeconds } from '@/lib/account-server'
import { problem, requireSameOrigin } from '@/lib/cart-server'

export const dynamic = 'force-dynamic'

export async function POST(request: Request, { params }: { params: Promise<{ action: string }> }) {
  if (!requireSameOrigin(request)) return problem('Request origin rejected.', 403)
  if (request.headers.get('content-type')?.split(';')[0]?.trim() !== 'application/json') return problem('JSON required.', 415)
  if (Number(request.headers.get('content-length') || 0) > 3000) return problem('Invalid request size.', 413)
  const { action } = await params
  if (!['login', 'register', 'logout', 'recovery', 'reset'].includes(action)) return problem('Not found.', 404)
  if (action === 'logout') {
    const token = await customerSession()
    if (token) await bridgeRequest('/auth/logout', 'POST', {}, token)
    const response = noStore({ ok: true })
    response.cookies.set(sessionCookie, '', { path: '/', maxAge: 0 })
    return response
  }
  let raw: Record<string, unknown>
  try {
    const data: unknown = await request.json()
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('Invalid')
    raw = data as Record<string, unknown>
  } catch { return problem('Invalid request.', 400) }
  const fields = action === 'login' ? ['login','password'] : action === 'register' ? ['username','email','password'] : action === 'recovery' ? ['login'] : ['login','key','password']
  for (const field of fields) {
    if (typeof raw[field] !== 'string' || !(raw[field] as string).trim() || (raw[field] as string).length > 256) return problem('Invalid account information.', 400)
  }
  const payload: Record<string, string> = {}
  for (const field of fields) payload[field] = (raw[field] as string)
  const clientIp = request.headers.get('cf-connecting-ip') || request.headers.get('x-real-ip') || request.headers.get('x-forwarded-for') || 'unknown'
  const reply = await bridgeRequest(`/auth/${action}`, 'POST', payload, undefined, clientIp)
  if (action === 'recovery' || action === 'reset') return noStore(reply.data, reply.status)
  if (reply.status !== 200 || typeof reply.data.token !== 'string' || !/^[a-f0-9]{64}$/.test(reply.data.token)) {
    return noStore({ error: typeof reply.data.error === 'string' ? reply.data.error : 'Authentication failed.' }, reply.status === 200 ? 502 : reply.status)
  }
  const response = NextResponse.json({ ok: true }, { headers: { 'Cache-Control': 'no-store' } })
  response.cookies.set(sessionCookie, reply.data.token, {
    httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production',
    path: '/', maxAge: sessionSeconds,
  })
  return response
}
