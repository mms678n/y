import { NextResponse } from 'next/server'
export const dynamic = 'force-dynamic'
export async function GET() {
  return NextResponse.json({ ok: true, mode: process.env.DEMO_MODE === 'false' ? 'live' : 'demo', service: 'rsvx7-storefront' }, { headers: { 'Cache-Control': 'no-store' } })
}
