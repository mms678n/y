import { bridgeRequest, customerSession, unauthorized } from '@/lib/account-server'
import { NextResponse } from 'next/server'
import { wpUrl } from '@/lib/woocommerce'
export const dynamic = 'force-dynamic'
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await customerSession()
  if (!session) return unauthorized()
  const { id } = await params
  if (!/^[a-f0-9]{64}$/.test(id)) return new NextResponse('Not found.', { status: 404 })
  const resolve = await bridgeRequest('/account/download-resolve', 'POST', { id }, session)
  if (resolve.status !== 200 || typeof resolve.data.url !== 'string') return new NextResponse('Download unavailable.', { status: 404 })
  let publicUrl: URL
  try {
    publicUrl = new URL(resolve.data.url)
    if (publicUrl.origin !== new URL(wpUrl).origin || !publicUrl.searchParams.has('download_file') || !publicUrl.searchParams.has('key')) throw new Error('Invalid location')
  } catch { return new NextResponse('Download unavailable.', { status: 404 }) }
  const internal = new URL(process.env.WC_INTERNAL_URL || 'http://rsvx7-wp-wordpress-1')
  const target = new URL(publicUrl.pathname + publicUrl.search, internal)
  let upstream: Response
  try {
    upstream = await fetch(target, {
      headers: { Host: new URL(wpUrl).host, 'X-Forwarded-Proto': 'https' },
      redirect: 'manual', cache: 'no-store', signal: AbortSignal.timeout(60_000),
    })
  } catch { return new NextResponse('Download unavailable.', { status: 502 }) }
  if (!upstream.ok || !upstream.body) return new NextResponse('Download unavailable.', { status: 502 })
  const headers = new Headers({
    'Content-Type': upstream.headers.get('content-type') || 'application/octet-stream',
    'Cache-Control': 'private, no-store',
    'X-Content-Type-Options': 'nosniff',
    'Content-Security-Policy': "default-src 'none'; sandbox",
  })
  const disposition = upstream.headers.get('content-disposition')
  if (disposition && !/[\r\n]/.test(disposition)) headers.set('Content-Disposition', disposition)
  else headers.set('Content-Disposition', 'attachment')
  return new NextResponse(upstream.body, { status: 200, headers })
}
