import { cookies } from 'next/headers'
import { createHmac } from 'node:crypto'
import { bridgeRequest, customerSession } from '@/lib/account-server'
import { NextResponse } from 'next/server'
import { problem, requireSameOrigin, requestWoo, WooProxyError, wooError, cartCookieName } from '@/lib/cart-server'
import { receiptCookie, receiptMaxAge, signReceipt } from '@/lib/receipt'

export const dynamic = 'force-dynamic'
const allowed = new Set((process.env.WC_ALLOWED_CHECKOUT_METHODS || 'bacs,cheque').split(',').map(s => s.trim()).filter(Boolean))
const inFlight = new Set<string>()

export async function POST(req: Request) {
  if (!requireSameOrigin(req)) return problem('Cross-site checkout blocked.', 403)
  if (req.headers.get('content-type')?.split(';')[0]?.trim() !== 'application/json') return problem('JSON is required.', 415)
  if (Number(req.headers.get('content-length') || 0) > 12000) return problem('Checkout payload too large.', 413)
  let data: Record<string, unknown>
  try { data = await req.json() } catch { return problem('Invalid JSON.') }
  if (!data || typeof data !== 'object' || Array.isArray(data)) return problem('Invalid request.')
  const payment = data.payment_method
  if (typeof payment !== 'string' || !allowed.has(payment)) return problem('Payment method not permitted in this storefront.', 400)
  const b = data.billing_address
  if (!b || typeof b !== 'object' || Array.isArray(b)) return problem('Billing address is required.')
  const billing = b as Record<string, unknown>
  for (const field of ['first_name','last_name','email','country']) {
    if (typeof billing[field] !== 'string' || !(billing[field] as string).trim() || (billing[field] as string).length > 160) return problem(`Invalid billing ${field}`)
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(billing.email))) return problem('Invalid email address.')
  if (!/^[A-Z]{2}$/.test(String(billing.country))) return problem('Country code must be two capital letters.')
  const fields = ['first_name','last_name','company','address_1','address_2','city','state','postcode','country','email','phone']
  const address: Record<string,string> = {}
  for (const field of fields) {
    const v = billing[field]
    if (v !== undefined && (typeof v !== 'string' || v.length > 160)) return problem('Invalid billing field.')
    address[field] = typeof v === 'string' ? v.trim() : ''
  }
  if (typeof data.expected_total !== 'string' || !/^\d{1,20}$/.test(data.expected_total)) return problem('Cart total is required.')
  const customer = await customerSession()
  if (!customer) return problem('Sign in to complete your order.', 401)
  const cookieJar = await cookies()
  const cartToken = cookieJar.get(cartCookieName)?.value
  if (!cartToken) return problem('Cart session missing. Return to the cart before checkout.', 409)
  if (inFlight.has(cartToken)) return problem('An order is already being submitted. Check your orders before retrying.', 409)

  inFlight.add(cartToken)
  try {
    const cart = await requestWoo('/cart', 'GET')
    if (cart.status !== 200) return problem('Cannot verify the cart with WooCommerce.', 502)
    const items = cart.data.items
    if (!Array.isArray(items) || items.length === 0) return problem('Your cart is empty.', 409)
    if (cart.data.needs_shipping === true) return problem('This checkout supports digital products only.', 409)
    const totals = cart.data.totals
    const total = totals && typeof totals === 'object' ? (totals as Record<string, unknown>).total_price : undefined
    if (typeof total !== 'string' || total !== data.expected_total) return problem('Cart total changed. Refresh checkout and review the new total.', 409)
    const methods = cart.data.payment_methods
    if (!Array.isArray(methods) || !methods.includes(payment)) return problem('The selected payment method is not currently enabled in WooCommerce.', 409)
    const fingerprint = createHmac('sha256', process.env.WC_RECEIPT_SECRET || '').update(cartToken).digest('hex')
    const claimed = await bridgeRequest('/checkout/claim', 'POST', { fingerprint }, customer)
    if (claimed.status !== 200 || claimed.data.claimed !== true) return problem(typeof claimed.data.error === 'string' ? claimed.data.error : 'Checkout unavailable. Check your order history.', claimed.status === 200 ? 409 : claimed.status)
    const payload = { billing_address: address, shipping_address: address, payment_method: payment, payment_data: [], expected_total: total }
    const result = await requestWoo('/checkout', 'POST', payload)
    if (result.status < 200 || result.status >= 300) {
      const message = typeof result.data.message === 'string' ? result.data.message : 'WooCommerce checkout failed.'
      return problem(message.slice(0, 240), result.status)
    }
    const paymentResult = result.data.payment_result
    if (paymentResult && typeof paymentResult === 'object' && (paymentResult as Record<string, unknown>).payment_status === 'failure') return problem('WooCommerce reports a failed payment. Check your order before trying again.', 409)
    const id = result.data.order_id
    const status = result.data.status
    if (typeof id !== 'number' || !Number.isSafeInteger(id) || id < 1 || typeof status !== 'string' || status === 'failed') {
      return problem('Order result requires review in WooCommerce before retrying.', 502)
    }
    const completed = await bridgeRequest('/checkout/complete', 'POST', { fingerprint, order_id: id }, customer)
    if (completed.status !== 200 || completed.data.ok !== true) return problem('Order created. Please review your account before any retry.', 409)
    const orderNumber = typeof result.data.order_number === 'string' ? result.data.order_number : String(id)
    const token = signReceipt({ order_id: id, order_number: orderNumber, status, payment_method: payment, created: Date.now() })
    const response = NextResponse.json({ ok: true, next: '/order-confirmation', status }, { headers: { 'Cache-Control': 'no-store' } })
    response.cookies.set(receiptCookie, token, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: receiptMaxAge })
    response.cookies.set(cartCookieName, '', { path: '/', maxAge: 0 })
    return response
  } catch (err) {
    if (!(err instanceof WooProxyError)) console.error('Checkout processing error:', err instanceof Error ? err.message : 'unknown')
    return wooError(err)
  } finally {
    inFlight.delete(cartToken)
  }
}
