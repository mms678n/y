import Link from 'next/link'
import { cookies } from 'next/headers'
import { ArrowUpRight, CheckCircle2, Clock3, Download } from 'lucide-react'
import { readReceipt, receiptCookie } from '@/lib/receipt'
export const dynamic = 'force-dynamic'
export const metadata = { title: 'Order Status — RSVX7 STORE', robots: { index: false, follow: false } }
export default async function Confirmation() {
  const jar = await cookies()
  const receipt = readReceipt(jar.get(receiptCookie)?.value)
  const paid = receipt && ['processing','completed'].includes(receipt.status)
  return <main className="page-main"><div className="container"><div className="page-intro"><span className="eyebrow">WOOCOMMERCE / ORDER STATUS</span><h1>ORDER <span>STATUS.</span></h1><p>Your order is processed and verified by WooCommerce, not by this display page.</p></div>
    {receipt ? <div className="result-panel">{paid ? <CheckCircle2 size={44}/> : <Clock3 size={44}/>}<h2>{paid ? 'ORDER CONFIRMED.' : 'ORDER RECEIVED.'}</h2><p>Order #{receipt.order_number} · Status: <strong>{receipt.status.toUpperCase()}</strong></p><p>{paid ? 'WooCommerce reports the order as processing or completed. Your digital downloads will be available according to the product and account permissions configured in WordPress.' : 'Payment is not confirmed yet. A manual bank transfer order normally stays on hold until the store verifies payment. Do not pay twice or place a duplicate order.'}</p><div style={{display:'flex',gap:'12px',flexWrap:'wrap',marginTop:'22px'}}><a className="button button-light" href="/account" >VIEW ORDERS <ArrowUpRight size={18}/></a><a className="button button-outline" href="/account" ><Download size={18}/> DOWNLOADS</a></div><p className="muted-note">Order status shown is the checkout response at submission time; check WooCommerce for the latest status. Never use this page as proof of payment.</p></div> : <div className="result-panel"><Clock3 size={44}/><h2>NO LOCAL RECEIPT FOUND.</h2><p>Your recent order confirmation is only displayed for 24 hours on the same browser. Check your WooCommerce account for existing orders before attempting another payment.</p><a className="button button-light" href="/account" >OPEN ORDER HISTORY <ArrowUpRight size={18}/></a></div>}
    <Link href="/shop" className="back-link cart-back">CONTINUE BROWSING <ArrowUpRight size={16}/></Link></div></main>
}
