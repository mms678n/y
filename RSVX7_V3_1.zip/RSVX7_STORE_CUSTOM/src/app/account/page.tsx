import { AccountHub } from '@/components/account/account-hub'
export const metadata = { title: 'Account — RSVX7 STORE', robots: { index: false, follow: false } }
export default function Account() { return <AccountHub /> }
