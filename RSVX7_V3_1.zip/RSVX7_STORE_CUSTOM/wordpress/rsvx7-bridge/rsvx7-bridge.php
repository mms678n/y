<?php
/**
 * Plugin Name: RSVX7 Commerce Bridge
 * Description: Authenticated storefront accounts and persistent checkout guards.
 * Version: 3.1.0
 * Requires Plugins: woocommerce
 */
if (!defined('ABSPATH')) { exit; }

function rsvx7_table($which) {
    global $wpdb;
    return $wpdb->prefix . 'rsvx7_' . $which;
}

function rsvx7_activate() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $collate = $wpdb->get_charset_collate();
    dbDelta('CREATE TABLE ' . rsvx7_table('sessions') . " (
        token_hash char(64) NOT NULL,
        user_id bigint(20) unsigned NOT NULL,
        expires_at datetime NOT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY  (token_hash),
        KEY user_id (user_id),
        KEY expires_at (expires_at)
    ) $collate;");
    dbDelta('CREATE TABLE ' . rsvx7_table('checkouts') . " (
        fingerprint char(64) NOT NULL,
        user_id bigint(20) unsigned NOT NULL,
        state varchar(20) NOT NULL,
        order_id bigint(20) unsigned NOT NULL DEFAULT 0,
        created_at datetime NOT NULL,
        PRIMARY KEY  (fingerprint),
        KEY user_id (user_id)
    ) $collate;");
}
register_activation_hook(__FILE__, 'rsvx7_activate');

function rsvx7_session_user($token) {
    global $wpdb;
    if (!is_string($token) || !preg_match('/^[a-f0-9]{64}$/D', $token)) return 0;
    $table = rsvx7_table('sessions');
    $id = $wpdb->get_var($wpdb->prepare(
        "SELECT user_id FROM $table WHERE token_hash = %s AND expires_at > %s LIMIT 1",
        hash('sha256', $token), gmdate('Y-m-d H:i:s')
    ));
    return $id ? (int) $id : 0;
}

function rsvx7_request_user($request) {
    $session = (string) $request->get_header('X-Rsvx7-Session');
    if ($session) return rsvx7_session_user($session);
    $auth = (string) $request->get_header('Authorization');
    return strpos($auth, 'Bearer ') === 0 ? rsvx7_session_user(substr($auth, 7)) : 0;
}

function rsvx7_data($payload, $code = 200) {
    $response = new WP_REST_Response($payload, $code);
    $response->header('Cache-Control', 'no-store, private');
    $response->header('X-Content-Type-Options', 'nosniff');
    return $response;
}

function rsvx7_limit($name, $max, $seconds) {
    $key = 'rv3_' . hash('sha256', $name);
    $count = (int) get_transient($key);
    if ($count >= $max) return false;
    set_transient($key, $count + 1, $seconds);
    return true;
}

function rsvx7_login($request) {
    $login = trim((string) $request->get_param('login'));
    $password = (string) $request->get_param('password');
    if (!$login || strlen($login) > 150 || strlen($password) > 256) {
        return rsvx7_data(['error' => 'Invalid credentials.'], 400);
    }
    if (!rsvx7_limit('login_' . strtolower($login), 12, 900)) {
        return rsvx7_data(['error' => 'Too many attempts. Try later.'], 429);
    }
    $user = wp_authenticate($login, $password);
    if (is_wp_error($user)) return rsvx7_data(['error' => 'Invalid credentials.'], 401);
    if (!in_array('customer', $user->roles, true) && !in_array('subscriber', $user->roles, true)) {
        return rsvx7_data(['error' => 'This account cannot use customer login.'], 403);
    }
    return rsvx7_issue_session($user);
}

function rsvx7_recovery($request) {
    $login = trim((string) $request->get_param('login'));
    if (strlen($login) > 160 || !$login) return rsvx7_data(['ok' => true]);
    if (!rsvx7_limit('recovery_' . strtolower($login), 3, HOUR_IN_SECONDS)) return rsvx7_data(['ok' => true]);
    $user = strpos($login, '@') !== false ? get_user_by('email', $login) : get_user_by('login', $login);
    if ($user && (in_array('customer', $user->roles, true) || in_array('subscriber', $user->roles, true))) {
        $key = get_password_reset_key($user);
        if (!is_wp_error($key)) {
            $base = (string) get_option('rsvx7_ui_public_url', '');
            if ($base && filter_var($base, FILTER_VALIDATE_URL) && parse_url($base, PHP_URL_SCHEME) === 'https') {
                $url = add_query_arg(['key' => $key, 'login' => $user->user_login], rtrim($base, '/') . '/reset-password');
                $subject = 'RSVX7 STORE | Reset your password';
                $html = '<!doctype html><html><body style="background:#f1f1f1;padding:28px 14px;font-family:Arial,Helvetica,sans-serif;color:#111">'
                    . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center">'
                    . '<table role="presentation" style="max-width:520px;background:#fff;border:1px solid #d9d9d9" width="100%" cellpadding="0" cellspacing="0">'
                    . '<tr><td style="background:#111;color:#fff;padding:28px 34px;font-size:22px;font-weight:700;letter-spacing:2px">RSVX7 <span style="font-weight:400;color:#bbb">/ STORE</span></td></tr>'
                    . '<tr><td style="padding:34px"><h1 style="font-size:25px;line-height:1.25;margin:0 0 15px">Reset your password</h1>'
                    . '<p style="font-size:14px;line-height:1.8;color:#555">A password reset was requested for your account. Use the button below to create a new password.</p>'
                    . '<p style="padding:18px 0 22px"><a href="' . esc_url($url) . '" style="display:inline-block;background:#111;color:#fff;text-decoration:none;padding:16px 26px;font-size:13px;font-weight:700;letter-spacing:1px">RESET PASSWORD</a></p>'
                    . '<p style="font-size:12px;line-height:1.7;color:#777">If you did not request this, you can ignore this email. Never share the link.</p>'
                    . '</td></tr></table></td></tr></table></body></html>';
                $sent = wp_mail($user->user_email, $subject, $html, ['Content-Type: text/html; charset=UTF-8']);
                if (!$sent && function_exists('wc_get_logger')) {
                    wc_get_logger()->warning('Password reset email could not be handed to the mailer.', ['source' => 'rsvx7-auth']);
                }
            }
        }
    }
    return rsvx7_data(['ok' => true]);
}

function rsvx7_reset($request) {
    $login = (string) $request->get_param('login');
    $key = (string) $request->get_param('key');
    $password = (string) $request->get_param('password');
    if (!$login || strlen($login) > 160 || !$key || strlen($key) > 120 || strlen($password) < 12 || strlen($password) > 128) return rsvx7_data(['error' => 'Invalid reset request.'], 400);
    $user = check_password_reset_key($key, $login);
    if (is_wp_error($user)) return rsvx7_data(['error' => 'Reset link has expired or is invalid.'], 400);
    if (!in_array('customer', $user->roles, true) && !in_array('subscriber', $user->roles, true)) return rsvx7_data(['error' => 'Reset not available.'], 403);
    reset_password($user, $password);
    global $wpdb;
    $wpdb->delete(rsvx7_table('sessions'), ['user_id' => $user->ID], ['%d']);
    return rsvx7_data(['ok' => true]);
}

function rsvx7_issue_session($user) {
    global $wpdb;
    $token = bin2hex(random_bytes(32));
    $expires = time() + 7 * DAY_IN_SECONDS;
    $ok = $wpdb->insert(rsvx7_table('sessions'), [
        'token_hash' => hash('sha256', $token),
        'user_id' => $user->ID,
        'created_at' => gmdate('Y-m-d H:i:s'),
        'expires_at' => gmdate('Y-m-d H:i:s', $expires),
    ], ['%s','%d','%s','%s']);
    if (!$ok) return rsvx7_data(['error' => 'Could not create a session.'], 500);
    return rsvx7_data(['token' => $token, 'expires_in' => 7 * DAY_IN_SECONDS]);
}

function rsvx7_register($request) {
    $username = trim((string) $request->get_param('username'));
    $email = trim((string) $request->get_param('email'));
    $password = (string) $request->get_param('password');
    $client = (string) $request->get_header('X-Rsvx7-Client');
    if (!rsvx7_limit('register_' . $client, 100, DAY_IN_SECONDS) || !rsvx7_limit('register_email_' . strtolower($email), 5, DAY_IN_SECONDS)) {
        return rsvx7_data(['error' => 'Registration limit exceeded.'], 429);
    }
    if (!preg_match('/^[a-zA-Z0-9_-]{3,32}$/D', $username) || !is_email($email) || strlen($email) > 160 || strlen($password) < 12 || strlen($password) > 128) {
        return rsvx7_data(['error' => 'Check your username, email and password.'], 400);
    }
    if (username_exists($username) || email_exists($email)) return rsvx7_data(['error' => 'Account details already in use.'], 409);
    if (!function_exists('wc_create_new_customer')) return rsvx7_data(['error' => 'Store is unavailable.'], 503);
    $id = wc_create_new_customer($email, $username, $password);
    if (is_wp_error($id)) return rsvx7_data(['error' => 'Could not create account.'], 400);
    return rsvx7_issue_session(get_user_by('id', $id));
}

function rsvx7_logout($request) {
    global $wpdb;
    $auth = (string) $request->get_header('Authorization');
    $token = (string) $request->get_header('X-Rsvx7-Session');
    if ($token || strpos($auth, 'Bearer ') === 0) {
        if (!$token) $token = substr($auth, 7);
        if (preg_match('/^[a-f0-9]{64}$/D', $token)) {
            $wpdb->delete(rsvx7_table('sessions'), ['token_hash' => hash('sha256', $token)], ['%s']);
        }
    }
    return rsvx7_data(['ok' => true]);
}

function rsvx7_account($request) {
    $id = rsvx7_request_user($request);
    if (!$id) return rsvx7_data(['error' => 'Please sign in.'], 401);
    $user = get_userdata($id);
    if (!$user) return rsvx7_data(['error' => 'Account unavailable.'], 404);
    return rsvx7_data([
        'id' => $id,
        'username' => $user->user_login,
        'name' => $user->display_name,
        'email' => $user->user_email,
        'first_name' => (string) get_user_meta($id, 'first_name', true),
        'last_name' => (string) get_user_meta($id, 'last_name', true),
    ]);
}

function rsvx7_orders($request) {
    $id = rsvx7_request_user($request);
    if (!$id) return rsvx7_data(['error' => 'Please sign in.'], 401);
    if (!function_exists('wc_get_orders')) return rsvx7_data(['error' => 'Store is unavailable.'], 503);
    $orders = wc_get_orders(['customer_id' => $id, 'limit' => 30, 'orderby' => 'date', 'order' => 'DESC']);
    $result = [];
    foreach ($orders as $order) {
        $result[] = [
            'id' => $order->get_id(),
            'number' => $order->get_order_number(),
            'status' => $order->get_status(),
            'paid' => $order->is_paid(),
            'total' => $order->get_total(),
            'currency' => $order->get_currency(),
            'date' => $order->get_date_created() ? $order->get_date_created()->date('c') : '',
            'items' => array_map(static function($item) {
                return ['name' => $item->get_name(), 'quantity' => $item->get_quantity()];
            }, array_values($order->get_items())),
        ];
    }
    return rsvx7_data(['orders' => $result]);
}

function rsvx7_downloads($request) {
    $id = rsvx7_request_user($request);
    if (!$id) return rsvx7_data(['error' => 'Please sign in.'], 401);
    if (!function_exists('wc_get_customer_available_downloads')) return rsvx7_data(['error' => 'Store unavailable.'], 503);
    $items = [];
    foreach (wc_get_customer_available_downloads($id) as $download) {
        $items[] = [
            'id' => hash('sha256', $download['download_url']),
            'order_id' => (int) $download['order_id'],
            'product_name' => sanitize_text_field($download['product_name']),
            'download_name' => sanitize_text_field($download['download_name']),
            'remaining' => $download['downloads_remaining'],
            'expires' => $download['access_expires'],
        ];
    }
    return rsvx7_data(['downloads' => $items]);
}

function rsvx7_download_resolve($request) {
    $id = rsvx7_request_user($request);
    if (!$id) return rsvx7_data(['error' => 'Please sign in.'], 401);
    $fingerprint = (string) $request->get_param('id');
    if (!preg_match('/^[a-f0-9]{64}$/D', $fingerprint)) return rsvx7_data(['error' => 'Invalid request.'], 400);
    foreach (wc_get_customer_available_downloads($id) as $download) {
        if (hash_equals(hash('sha256', $download['download_url']), $fingerprint)) {
            return rsvx7_data(['url' => $download['download_url']]);
        }
    }
    return rsvx7_data(['error' => 'Download not available.'], 404);
}

function rsvx7_wallet($request) {
    $id = rsvx7_request_user($request);
    if (!$id) return rsvx7_data(['error' => 'Please sign in.'], 401);
    if (!function_exists('woo_wallet')) return rsvx7_data(['enabled' => false]);
    try {
        $wallet = woo_wallet();
        if (!isset($wallet->wallet)) return rsvx7_data(['enabled' => false]);
        $balance = $wallet->wallet->get_wallet_balance($id, 'edit');
        if (!is_numeric($balance)) return rsvx7_data(['enabled' => false]);
        return rsvx7_data(['enabled' => true, 'balance' => (string) $balance, 'currency' => get_woocommerce_currency()]);
    } catch (Throwable $e) {
        return rsvx7_data(['enabled' => false]);
    }
}

function rsvx7_licenses($request) {
    $id = rsvx7_request_user($request);
    if (!$id) return rsvx7_data(['error' => 'Please sign in.'], 401);
    if (!function_exists('lmfwc_get_licenses')) return rsvx7_data(['enabled' => false, 'licenses' => []]);
    $found = lmfwc_get_licenses(['user_id' => $id]);
    $licenses = [];
    if (is_array($found)) {
        foreach ($found as $entry) {
            if (!is_object($entry) || !method_exists($entry, 'getOrderId')) continue;
            $order_id = (int) $entry->getOrderId();
            $order = $order_id && function_exists('wc_get_order') ? wc_get_order($order_id) : false;
            if (!$order || (int) $order->get_customer_id() !== $id || !$order->is_paid()) continue;
            $licenses[] = [
                'order_id' => $order_id,
                'product_id' => method_exists($entry, 'getProductId') ? (int) $entry->getProductId() : 0,
                'key' => method_exists($entry, 'getLicenseKey') ? (string) $entry->getLicenseKey() : '',
                'status' => method_exists($entry, 'getStatus') ? (string) $entry->getStatus() : '',
            ];
        }
    }
    return rsvx7_data(['enabled' => true, 'licenses' => $licenses]);
}

function rsvx7_checkout_guard($request, $finalize = false) {
    global $wpdb;
    $user = rsvx7_request_user($request);
    if (!$user) return rsvx7_data(['error' => 'Please sign in.'], 401);
    $fingerprint = (string) $request->get_param('fingerprint');
    if (!preg_match('/^[a-f0-9]{64}$/D', $fingerprint)) return rsvx7_data(['error' => 'Invalid checkout.'], 400);
    $table = rsvx7_table('checkouts');
    if ($finalize) {
        $order_id = (int) $request->get_param('order_id');
        $order = function_exists('wc_get_order') ? wc_get_order($order_id) : false;
        if (!$order || (int) $order->get_customer_id() !== $user) return rsvx7_data(['error' => 'Order ownership could not be verified.'], 409);
        $updated = $wpdb->update($table, ['state' => 'completed', 'order_id' => $order_id],
            ['fingerprint' => $fingerprint, 'user_id' => $user, 'state' => 'processing'],
            ['%s','%d'], ['%s','%d','%s']);
        return $updated === 1 ? rsvx7_data(['ok' => true]) : rsvx7_data(['error' => 'Checkout state needs review.'], 409);
    }
    $inserted = $wpdb->query($wpdb->prepare(
        "INSERT IGNORE INTO $table (fingerprint,user_id,state,order_id,created_at) VALUES (%s,%d,'processing',0,%s)",
        $fingerprint, $user, gmdate('Y-m-d H:i:s')
    ));
    if ($inserted === 1) return rsvx7_data(['claimed' => true]);
    $row = $wpdb->get_row($wpdb->prepare("SELECT user_id,state,order_id FROM $table WHERE fingerprint=%s", $fingerprint), ARRAY_A);
    if (!$row || (int) $row['user_id'] !== $user) return rsvx7_data(['error' => 'Checkout already claimed.'], 409);
    return rsvx7_data(['error' => 'This cart was already submitted. Review order history before retrying.', 'state' => $row['state']], 409);
}

add_filter('determine_current_user', static function($user_id) {
    if ($user_id || empty($_SERVER['REQUEST_URI']) || strpos($_SERVER['REQUEST_URI'], '/wc/store/v1/') === false) return $user_id;
    $token = isset($_SERVER['HTTP_X_RSVX7_SESSION']) ? (string) $_SERVER['HTTP_X_RSVX7_SESSION'] : '';
    return $token ? rsvx7_session_user($token) : $user_id;
}, 30);

add_action('rest_api_init', static function() {
    $routes = [
        ['auth/login','POST','rsvx7_login'],
        ['auth/register','POST','rsvx7_register'],
        ['auth/logout','POST','rsvx7_logout'],
        ['auth/recovery','POST','rsvx7_recovery'],
        ['auth/reset','POST','rsvx7_reset'],
        ['account/me','GET','rsvx7_account'],
        ['account/orders','GET','rsvx7_orders'],
        ['account/downloads','GET','rsvx7_downloads'],
        ['account/download-resolve','POST','rsvx7_download_resolve'],
        ['account/wallet','GET','rsvx7_wallet'],
        ['account/licenses','GET','rsvx7_licenses'],
    ];
    foreach ($routes as $route) {
        register_rest_route('rsvx7/v1', '/' . $route[0], [
            'methods' => $route[1],
            'callback' => $route[2],
            'permission_callback' => '__return_true',
        ]);
    }
    foreach (['claim' => false, 'complete' => true] as $action => $finalize) {
        register_rest_route('rsvx7/v1', '/checkout/' . $action, [
            'methods' => 'POST',
            'callback' => static function($request) use ($finalize) { return rsvx7_checkout_guard($request, $finalize); },
            'permission_callback' => '__return_true',
        ]);
    }
});

add_action('init', static function() {
    if (!wp_next_scheduled('rsvx7_bridge_cleanup')) {
        wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'rsvx7_bridge_cleanup');
    }
});
add_action('rsvx7_bridge_cleanup', static function() {
    global $wpdb;
    $sessions = rsvx7_table('sessions');
    $checkouts = rsvx7_table('checkouts');
    $wpdb->query($wpdb->prepare("DELETE FROM $sessions WHERE expires_at < %s", gmdate('Y-m-d H:i:s')));
    $wpdb->query($wpdb->prepare("DELETE FROM $checkouts WHERE created_at < %s", gmdate('Y-m-d H:i:s', time() - 60 * DAY_IN_SECONDS)));
});
register_deactivation_hook(__FILE__, static function() {
    wp_clear_scheduled_hook('rsvx7_bridge_cleanup');
});


function rsvx7_invoice_download() {
    nocache_headers();
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    $session = isset($_SERVER['HTTP_X_RSVX7_SESSION']) ? (string) $_SERVER['HTTP_X_RSVX7_SESSION'] : '';
    $user_id = rsvx7_session_user($session);
    $order_id = isset($_GET['order_id']) ? absint($_GET['order_id']) : 0;
    if (!$user_id || !$order_id || !function_exists('wc_get_order')) {
        status_header(404);
        exit;
    }
    $order = wc_get_order($order_id);
    if (!$order || (int) $order->get_customer_id() !== $user_id || !$order->is_paid()) {
        status_header(404);
        exit;
    }
    if (!function_exists('wcpdf_get_document')) {
        status_header(503);
        exit;
    }
    try {
        $document = wcpdf_get_document('invoice', $order);
        if (!$document || !method_exists($document, 'get_pdf')) {
            status_header(503);
            exit;
        }
        $pdf = $document->get_pdf();
        if (!is_string($pdf) || substr($pdf, 0, 5) !== '%PDF-' || strlen($pdf) > 8 * 1024 * 1024) {
            status_header(503);
            exit;
        }
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="RSVX7-INVOICE-' . $order_id . '.pdf"');
        header('Cache-Control: private, no-store, no-cache, must-revalidate');
        header('Content-Length: ' . strlen($pdf));
        echo $pdf;
        exit;
    } catch (Throwable $e) {
        if (function_exists('wc_get_logger')) {
            wc_get_logger()->error('Invoice generation failed for order ' . $order_id, ['source' => 'rsvx7-invoice']);
        }
        status_header(503);
        exit;
    }
}
add_action('admin_post_nopriv_rsvx7_invoice', 'rsvx7_invoice_download');
add_action('admin_post_rsvx7_invoice', 'rsvx7_invoice_download');

add_action('wpo_wcpdf_before_document', static function($type, $order) {
    if ($type !== 'invoice') return;
    $logo = __DIR__ . '/logo-invoice.png';
    $image = file_exists($logo) ? 'data:image/png;base64,' . base64_encode(file_get_contents($logo)) : '';
    echo '<table class="rsvx7-invoice-head" width="100%"><tr><td style="width:70px">';
    if ($image) echo '<img width="65" height="65" alt="RSVX7" src="' . esc_attr($image) . '">';
    echo '</td><td class="rsvx7-invoice-brand"><strong>RSVX7</strong> <span>/ STORE</span><div>DIGITAL COMMERCE</div></td>';
    echo '<td class="rsvx7-invoice-type">INVOICE<div>ONLINE ORDER</div></td></tr></table>';
}, 10, 2);

add_action('wpo_wcpdf_custom_styles', static function($document_type, $document = null) {
    if ($document_type !== 'invoice') return;
    echo '@page { margin: 16mm 17mm 22mm 17mm; }';
    echo 'body { color: #101010; font-family: DejaVu Sans, sans-serif; font-size: 9.5pt; }';
    echo 'table.head.container .header { display: none; }';
    echo '.rsvx7-invoice-head { width:100%; border-collapse:collapse; border-bottom: 2px solid #111; margin-bottom: 16mm; }';
    echo '.rsvx7-invoice-head td { padding: 0 0 13mm 0; vertical-align:middle; }';
    echo '.rsvx7-invoice-brand { font-size: 23pt; letter-spacing: 0.3px; white-space:nowrap; }';
    echo '.rsvx7-invoice-brand strong { font-weight:800; }';
    echo '.rsvx7-invoice-brand span { color:#555; font-weight:300; }';
    echo '.rsvx7-invoice-brand div { font-size:7pt; letter-spacing:3px; color:#777; padding-top:5px; }';
    echo '.rsvx7-invoice-type { text-align:right; font-size:16pt; font-weight:bold; }';
    echo '.rsvx7-invoice-type div { font-size:7pt; font-weight:normal; color:#777; letter-spacing:2px; padding-top:5px; }';
    echo '.document-type-label { font-size:21pt; letter-spacing:1px; margin:5mm 0 9mm; }';
    echo '.order-data-addresses { margin-bottom:10mm; }';
    echo '.order-data-addresses .order-data th { color:#777; font-weight:normal; }';
    echo '.order-details thead th { background:#111; color:#fff; padding:12px 9px; border:0; }';
    echo '.order-details tbody td { border-color:#dedede; padding:10px 9px; }';
    echo '.totals .order_total td, .totals .order_total th { border-top:2px solid #111; border-bottom:2px solid #111; font-size:12pt; }';
    echo '#footer { border-top:1px solid #bbb; color:#888; font-size:8pt; }';
}, 10, 2);
