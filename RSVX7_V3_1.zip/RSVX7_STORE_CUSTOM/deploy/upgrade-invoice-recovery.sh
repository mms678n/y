#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ -f .env && -f stack/compose.yaml ]] || { echo 'ERROR: An installed V3 store is required.' >&2; exit 1; }
command -v docker >/dev/null && command -v python3 >/dev/null || { echo 'ERROR: Docker and Python 3 are required.' >&2; exit 1; }
docker inspect rsvx7-wp-wordpress-1 >/dev/null
docker inspect rsvx7-custom-ui >/dev/null
docker cp wordpress/rsvx7-bridge/rsvx7-bridge.php rsvx7-wp-wordpress-1:/tmp/rsvx7-bridge-preflight.php
docker exec rsvx7-wp-wordpress-1 php -l /tmp/rsvx7-bridge-preflight.php
docker exec rsvx7-wp-wordpress-1 rm -f /tmp/rsvx7-bridge-preflight.php
python3 tests/v3-check.py
python3 tests/invoice-recovery-check.py
bash deploy/backup-v3.sh
wp(){ (cd stack && docker compose --profile tools run --rm -T cli "$@"); }
wp plugin is-active woocommerce >/dev/null
printf '
=== ADD PDF AND MAIL PROVIDERS ===
'
if wp plugin is-installed woocommerce-pdf-invoices-packing-slips >/dev/null 2>&1; then
  wp plugin activate woocommerce-pdf-invoices-packing-slips
else
  wp plugin install woocommerce-pdf-invoices-packing-slips --activate
fi
if wp plugin is-installed wp-mail-smtp >/dev/null 2>&1; then
  wp plugin activate wp-mail-smtp
else
  wp plugin install wp-mail-smtp --activate
fi
printf '
=== BUILD V3.1 STOREFRONT ===
'
docker compose --progress plain build storefront
STAMP="$(date +%Y%m%d-%H%M%S)"
mkdir -p .v3-backups
if docker exec rsvx7-wp-wordpress-1 test -d /var/www/html/wp-content/plugins/rsvx7-bridge; then
  docker cp rsvx7-wp-wordpress-1:/var/www/html/wp-content/plugins/rsvx7-bridge ".v3-backups/bridge-$STAMP"
fi
PREVIOUS="$(docker inspect -f '{{.Image}}' rsvx7-custom-ui)"
docker image tag "$PREVIOUS" "rsvx7-ui-rollback:$STAMP"
docker cp wordpress/rsvx7-bridge/. rsvx7-wp-wordpress-1:/var/www/html/wp-content/plugins/rsvx7-bridge/
docker exec rsvx7-wp-wordpress-1 chown -R www-data:www-data /var/www/html/wp-content/plugins/rsvx7-bridge
docker exec rsvx7-wp-wordpress-1 php -l /var/www/html/wp-content/plugins/rsvx7-bridge/rsvx7-bridge.php
wp plugin activate rsvx7-bridge
wp option update rsvx7_ui_public_url 'https://ui.rsvx7-store.com'
printf '
=== REPLACE STOREFRONT ===
'
docker compose up -d --no-build --no-deps --force-recreate storefront
ready=0
for i in $(seq 1 24); do
  if curl -fsS --max-time 6 http://127.0.0.1:3010/api/health >/dev/null 2>&1; then ready=1; break; fi
  sleep 3
done
if [[ "$ready" != 1 ]]; then
  echo 'ERROR: Storefront health check failed. Rolling back previous image.' >&2
  docker image tag "$PREVIOUS" rsvx7-custom-ui-storefront:latest
  docker compose up -d --no-build --no-deps --force-recreate storefront || true
  exit 1
fi
status="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 10 http://127.0.0.1:3010/api/invoice/1)"
[[ "$status" == '401' ]] || { echo "ERROR: Unauthenticated invoice route returned $status instead of 401." >&2; exit 1; }
wp plugin is-active woocommerce-pdf-invoices-packing-slips
wp plugin is-active wp-mail-smtp
printf '
=== V3.1 READY FOR TESTING ===
'
printf 'Invoice endpoint rejects unauthenticated access: HTTP %s
' "$status"
printf 'WordPress SMTP sender must be configured and tested before password reset email can be delivered.
'
printf 'Rollback image: rsvx7-ui-rollback:%s
' "$STAMP"
