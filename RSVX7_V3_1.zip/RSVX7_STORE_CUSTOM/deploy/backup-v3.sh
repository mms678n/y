#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ -f stack/.env ]] || { echo 'ERROR: Database configuration missing.' >&2; exit 1; }
free_kb="$(df -Pk "$ROOT" | awk 'NR==2 {print $4}')"
(( free_kb > 3 * 1024 * 1024 )) || { echo 'ERROR: Less than 3GB free, move backup storage before proceeding.' >&2; exit 1; }
umask 077
set -a
source stack/.env
set +a
OUT="$ROOT/backups/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$OUT"
docker inspect rsvx7-wp-db-1 >/dev/null 2>&1 || { echo 'ERROR: Database container not found.' >&2; exit 1; }
docker exec -e MYSQL_PWD="$DB_ROOT_PASSWORD" rsvx7-wp-db-1 mariadb-dump -uroot --single-transaction --quick --routines wordpress | gzip -1 > "$OUT/database.sql.gz"
docker exec rsvx7-wp-wordpress-1 tar -czf - -C /var/www/html/wp-content uploads > "$OUT/uploads.tar.gz"
cp .env "$OUT/storefront.env"
cp stack/.env "$OUT/database.env"
cp stack/Caddyfile "$OUT/Caddyfile"
chmod 600 "$OUT"/*
sha256sum "$OUT"/* > "$OUT/SHA256SUMS"
chmod 600 "$OUT/SHA256SUMS"
printf 'Backup created: %s\nStore the backup outside the VPS before launch.\n' "$OUT"
