#!/usr/bin/env bash
# Resume interrupted fresh install without overwriting secrets, volumes, users, or orders.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ -f .env && -f stack/.env && -f stack/compose.yaml && -f stack/Caddyfile ]] || {
 echo 'ERROR: Fresh installation was not initialized; use deploy/bootstrap-fresh.sh first.' >&2
 exit 1
}
(cd stack && docker compose config --quiet)
docker compose config --quiet
if ! docker network inspect rsvx7-shop-net >/dev/null 2>&1; then docker network create rsvx7-shop-net >/dev/null; fi
(cd stack && docker compose up -d db wordpress)
for i in $(seq 1 50); do
 if docker exec rsvx7-wp-wordpress-1 test -f /var/www/html/wp-config.php >/dev/null 2>&1; then break; fi
 sleep 2
done
wp(){ (cd stack && docker compose --profile tools run --rm -T cli "$@"); }
if ! wp core is-installed >/dev/null 2>&1; then
 echo 'ERROR: WordPress installation incomplete. No admin account overwritten.' >&2
 exit 1
fi
if ! wp plugin is-active woocommerce >/dev/null 2>&1; then
 wp plugin install woocommerce --activate
fi
docker exec rsvx7-wp-wordpress-1 mkdir -p /var/www/html/wp-content/plugins/rsvx7-bridge
docker cp "$ROOT/wordpress/rsvx7-bridge/." rsvx7-wp-wordpress-1:/var/www/html/wp-content/plugins/rsvx7-bridge/
docker exec rsvx7-wp-wordpress-1 chown -R www-data:www-data /var/www/html/wp-content/plugins/rsvx7-bridge
wp plugin activate rsvx7-bridge
wp option update rsvx7_ui_public_url "https://ui.rsvx7-store.com"
docker compose --progress plain build storefront
docker compose up -d --no-build storefront
for i in $(seq 1 30); do
 if curl -fsS --max-time 5 http://127.0.0.1:3010/api/health >/dev/null 2>&1; then break; fi
 sleep 3
done
curl -fsS --max-time 10 http://127.0.0.1:3010/api/health || {
 echo 'ERROR: UI has not passed health check; Caddy not changed.' >&2
 exit 1
}
(cd stack && docker compose up -d caddy)
exec bash deploy/verify-fresh.sh
