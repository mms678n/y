/* Offline signed-receipt test; does not connect to WooCommerce or create an order. */
const assert = require('node:assert/strict')
const fs = require('node:fs')
const Module = require('node:module')
const path = require('node:path')
const ts = require('typescript')
process.env.WC_RECEIPT_SECRET = 'a'.repeat(64)
const filepath = path.resolve(__dirname, '../src/lib/receipt.ts')
const source = fs.readFileSync(filepath, 'utf8')
const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText
const mod = new Module(filepath, module)
mod.filename = filepath
mod.paths = Module._nodeModulePaths(path.dirname(filepath))
mod._compile(compiled, filepath)
const { signReceipt, readReceipt } = mod.exports
const valid = { order_id: 42, order_number: '42', status: 'on-hold', payment_method: 'bacs', created: Date.now() }
const signature = signReceipt(valid)
assert.deepEqual(readReceipt(signature), valid)
assert.equal(readReceipt(signature + 'x'), null)
assert.equal(readReceipt('not-a-signature'), null)
assert.equal(readReceipt(signReceipt({...valid,created:Date.now()-90000000})), null)
assert.equal(readReceipt(signReceipt({...valid,created:Date.now()+90000000})), null)
console.log('PASS: HMAC receipt signing, verification, tampering, and expiry')
