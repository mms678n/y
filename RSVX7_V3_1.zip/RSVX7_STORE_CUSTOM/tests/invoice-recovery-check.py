from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
plugin = (root / 'wordpress/rsvx7-bridge/rsvx7-bridge.php').read_text()
ui = (root / 'src/components/account/account-hub.tsx').read_text()
proxy = (root / 'src/app/api/invoice/[id]/route.ts').read_text()
reset = (root / 'src/components/account/password-reset.tsx').read_text()
assert 'rsvx7_session_user($session)' in plugin
assert 'get_customer_id() !== $user_id' in plugin
assert '!$order->is_paid()' in plugin
assert "admin_post_nopriv_rsvx7_invoice" in plugin
assert "wpo_wcpdf_custom_styles" in plugin
assert 'Reset your password' in plugin
assert 'wp_mail(' in plugin
assert 'get_password_reset_key' in plugin
assert 'check_password_reset_key' in plugin
assert 'reset_password' in plugin
assert 'Invoice PDF' in ui
assert 'order.paid' in ui
assert 'customerSession()' in proxy
assert 'X-Rsvx7-Session' in proxy
assert "head !== '%PDF-'" in proxy
assert 'response.ok' in (root/'src/app/api/auth/[action]/route.ts').read_text() or 'reply.status' in (root/'src/app/api/auth/[action]/route.ts').read_text()
assert '/api/auth/' in reset
assert (root/'wordpress/rsvx7-bridge/logo-invoice.png').stat().st_size > 1024
assert 'Referrer-Policy' in (root/'next.config.ts').read_text()
assert 'plugin is-installed woocommerce-pdf-invoices-packing-slips' in (root/'deploy/upgrade-invoice-recovery.sh').read_text()
assert 'docker exec rsvx7-wp-wordpress-1 php -l' in (root/'deploy/upgrade-invoice-recovery.sh').read_text()
for path in [root/'wordpress/rsvx7-bridge/rsvx7-bridge.php']:
    p = subprocess.run(['php', '-l', str(path)], capture_output=True, text=True)
    assert p.returncode == 0, p.stdout + p.stderr
for path in (root/'deploy').glob('*.sh'):
    p = subprocess.run(['bash', '-n', str(path)], capture_output=True, text=True)
    assert p.returncode == 0, p.stdout + p.stderr
print('PASS: Invoice owner/paid checks, account integration, password recovery, PHP and Bash syntax')
